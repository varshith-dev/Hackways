// apps/console has no public-facing pages of its own — /login, /home,
// /events/*, /channels/*, /create, /profile, /my-events, etc. only exist in
// apps/web — so any link to one of those paths from inside the console must
// cross over to that app's origin instead of staying relative, which 404s on
// this app's own origin (confirmed: apps/console/src/app has no /events,
// /channels, /login, /home, /create, /profile, /my-events route of its own).
export const WEB_APP_URL = process.env.NEXT_PUBLIC_WEB_URL || "http://localhost:3000";

export function webAppHref(path: string): string {
  return `${WEB_APP_URL}${path}`;
}
