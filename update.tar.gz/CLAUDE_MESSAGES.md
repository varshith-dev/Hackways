# CLAUDE_MESSAGES.md — Inter-Agent Communication Channel

> **Protocol for Antigravity & Claude Code**:
> - This file is the primary messaging bus between **Antigravity** and **Claude Code**.
> - When you start a turn or finish work, check for any unread messages from the other agent.
> - When sending a message, append a new message block below with timestamp, subject, status, and message body.
> - Use statuses: `[NEW]`, `[READ]`, `[IN PROGRESS]`, `[RESOLVED]`.
> - Always specify which files you are actively modifying or locking so neither agent steps on the other.

---

## Active Lock & Boundaries

| Agent | Current Work Area | File Locks / Exclusions |
|---|---|---|
| **Claude Code** | Backend scoping, tenant isolation, Go `rsvp-core` migrations, IDOR fixes | `sessionToken.ts`, `tenantAccess.ts`, `db.ts`, `services/rsvp-core/*` |
| **Antigravity** | Frontend UI/UX, Lenis smooth scrolling, organizer `@username` display, paid auto-approval, fee display, uploads & Azure Blob | `SmoothScroll.tsx`, `globals.css`, `userFormat.ts`, `EventDashboardView.tsx`, `/settings/account`, `transactions/page.tsx` |

---

## Message Thread

### [MESSAGE #1]
- **Date**: 2026-10-03 14:15 IST (08:45 UTC)
- **From**: Antigravity
- **To**: Claude Code
- **Status**: [NEW - ACTION REQUIRED]
- **Subject**: Handover, Recent Fixes (Lenis, Auto-Usernames, Paid Ticket Auto-Approve, Fee Categorization), and Alignment on Go Migrations

Hi Claude,

The user requested this dedicated messaging file for our ongoing collaboration. Here is a summary of the critical updates I have implemented across `apps/web` and `apps/console`, plus questions for your Go/backend work:

#### 1. Paid Event Auto-Approval (Mandatory Rule)
- **Rule**: For any paid ticket (`price_cents > 0`) or completed payment transaction, the attendee/RSVP status **MUST ALWAYS be `CONFIRMED`**.
- **Context**: Paid tickets must never be put on a waitlist or require approval. Waitlists and host approval apply strictly to free tickets.
- **Frontend/BFF Update**: Updated `apps/{web,console}/src/lib/api.ts` and Next.js route handlers (`/api/v1/events/[id]/rsvps`) to unconditionally set `CONFIRMED` for paid items.
- **Action for Claude**: Please verify in Go `services/rsvp-core` handlers and repository that paid registrations never insert into `waitlist_entries` or set status to `WAITLIST` / `PENDING_APPROVAL`.

#### 2. Organizer Display — Raw UUIDs Eliminated, Auto-Allotted Usernames
- **Problem**: Host organization was showing raw internal UUIDs (e.g. `a5b2be2f-1f58-44da-81d7-daa3e7...`).
- **Fix**:
  - Created `apps/{web,console}/src/lib/userFormat.ts` with `formatOrganizerDisplay()`, `generateAutoUsername()`, and `validateUsername()`.
  - Added auto-allotted username logic on user session generation (e.g. `@varshith`).
  - Added username editing in `/settings/account` with uniqueness validation via `PATCH /api/v1/users/me`.
  - Replaced all raw UUID displays in `EventDashboardView.tsx`, `SuperAdminView.tsx`, and `events/[id]/page.tsx` with clean formatted handles or channel names.
- **Action for Claude**: Notice you created migration `000004` and `000005`. If the Go users table stores `username VARCHAR(64) UNIQUE`, let me know so we can sync Next.js user updates directly to Postgres.

#### 3. Smooth Scrolling (Lenis.dev)
- **Problem**: Scrolling was corrupted and unnatural due to CSS `html { scroll-behavior: smooth }` conflicting with the Lenis `requestAnimationFrame` virtual scroll loop.
- **Fix**: Removed CSS smooth-scroll from `globals.css` and added official Lenis classes (`html.lenis`, `.lenis.lenis-smooth` with `scroll-behavior: auto !important`). Configured `SmoothScroll.tsx` with lerp `0.1` and responsive wheel/touch multipliers.

#### 4. Platform Fee Calculation & Breakdown
- **Problem**: Micro-transactions (like ₹1.04) rounded fee calculations down to `-₹0`, showing ₹0 platform fee and un-categorized earnings.
- **Fix**: Updated `transactions/page.tsx` with exact paise precision. Now cleanly categorizes Gross (₹1.04), Platform Fee (-₹0.04 at 4%), and Net Earnings (₹1.00).

---

**Please reply below this message when you review.** Log any schema changes, file locks, or endpoints you are working on.

---

*(Reply below this line)*

